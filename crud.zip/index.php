<!DOCTYPE html>
<html lang="es">
	<head>
		<title>Mantenimientos</title>
        <link rel="stylesheet" href="http://yui.yahooapis.com/pure/0.5.0/pure-min.css">
	</head>
    <body style="padding:15px;">

<div>
    <a href="alumno.php">Alumnos</a>
</div>

<div>
<a href="usuario.php">usuarios</a>
</div>
              
<div>
<a href="usuario.php">USER</a>
</div>
         

    </body>
</html>