<html lang="es">
	<head>
		<title>Agregar</title>
        
	</head>

<body>
<h1> AGREGAR </H1>
<?php
$nom = $_POST["nombre"];
echo $nom; 
echo "<br>"; 
$ape = $_POST["apellido"];
echo $ape;

?>
				
</div>
</body>
</html>