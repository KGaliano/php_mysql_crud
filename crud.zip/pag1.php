<html lang="es">
	<head>
		<title>Mantenimiento</title>
        
	</head>

<body>

<form action="pag2.php" method="post">
	<input type="hidden" name="id" value="registro" />
	
Nombre  <input type="text" name="nombre" value="" /> <br>
Apellido<input type="text" name="apellido" value="" /> <br>

<button type="submit" >Enviar</button>

</form>
				
</div>
</body>
</html>